3D File models were downloaded from:

http://graphics.stanford.edu/data/3Dscanrep/

The original PLY files were renamed for simplicity.
dragon_vrip_res4.ply was renamed to dragon.ply
bun_zipper_res4.ply was renamed to bunny_low.ply
bun_zipper.ply was renamed to bunny.ply

Please visit http://www-graphics.stanford.edu if you'd like more information about these models.